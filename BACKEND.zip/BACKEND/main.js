// // main.js
// const express = require('express');
// const session = require('express-session'); // Add session support
// const cors = require('cors');
// const { poolPromise } = require('./db'); // Import database connection
// const authRoutes = require('./authRoutes'); // Import authentication routes
// const appRoutes = require('./appRoutes'); // Import application routes
// const userRoutes = require('./userRoutes');
// const nodemailer = require('nodemailer'); // For sending emails
// const { google } = require('google-auth-library');
// const app = express();

// app.use(cors({
//     origin: 'http://127.0.0.1:5500',  // Your frontend's origin
//     credentials: true  // Allow credentials to be sent
// }));

// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// // Session setup
// app.use(session({
//     secret: '123456789',
//     resave: false,
//     saveUninitialized: true,
//     cookie: { secure: false, 
//               httpOnly: true, 
//               sameSite: 'None',  // Keep SameSite=None for cross-site requests   
//             // sameSite: 'Lax',  // Use 'Lax' during local development instead of 'None' 
//               maxAge: 1000 * 60 * 60 * 24 } // Set to true if using HTTPS
// }));


// // Use routes
// app.use((req, res, next) => {
//     console.log(`Request URL: ${req.url}`);
//     console.log("Session data: ",req.session);
//     next();
// });


// app.use('/', authRoutes); // Prefix routes for authentication
// app.use('/', userRoutes);
// app.use('/', appRoutes); // Prefix routes for application pages


// // Error handling middleware
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).json({ message: 'Something went wrong!' });
// });


// // Start server
// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//     console.log(`Server running on port ${PORT}`);
// });


// const express = require('express');
// const session = require('express-session');
// const cors = require('cors');
// const { createProxyMiddleware } = require('http-proxy-middleware'); // Import proxy middleware
// const { poolPromise } = require('./db');
// const authRoutes = require('./authRoutes');
// const appRoutes = require('./appRoutes');
// const userRoutes = require('./userRoutes');
// const nodemailer = require('nodemailer');

// const app = express();

// // Set CORS options
// const corsOptions = {
//     origin: 'http://127.0.0.1:5500', // Your frontend's origin
//     credentials: true, // Allow credentials to be sent
// };

// // Enable CORS with custom headers
// app.use(cors(corsOptions));

// app.use(express.json());
// app.use(express.urlencoded({ extended: true }));

// // Session setup
// app.use(session({
//     secret: '123456789',
//     resave: false,
//     saveUninitialized: true,
//     cookie: { 
//         secure: false, // Set to true if using HTTPS
//         httpOnly: true,
//         sameSite: 'Lax',  // Use 'Lax' for local development
//     }
// }));

// // Custom middleware to set headers
// app.use((req, res, next) => {
//     res.header('Access-Control-Allow-Origin', 'http://127.0.0.1:5500'); // Set your frontend's origin
//     res.header('Access-Control-Allow-Credentials', 'true'); // Allow credentials
//     res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization'); // Specify allowed headers
//     // Allow methods (GET, POST, etc.) if necessary
//     res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); // Allow specific HTTP methods
//     console.log(`Request URL: ${req.url}`);
//     console.log("Session data: ",req.session);
//     next();
// });


// // Use routes
// app.use('/', authRoutes);
// app.use('/', userRoutes);
// app.use('/', appRoutes);

// // Error handling middleware
// app.use((err, req, res, next) => {
//     console.error(err.stack);
//     res.status(500).json({ message: 'Something went wrong!' });
// });

// // Start server
// const PORT = process.env.PORT || 3000;
// app.listen(PORT, () => {
//     console.log(`Server running on http://localhost:${PORT}`);
// });



const express = require('express');
const session = require('express-session');
const cors = require('cors');
const cookieParser = require('cookie-parser'); // Add cookie-parser for handling cookies
const { poolPromise } = require('./db');
const authRoutes = require('./authRoutes');
const appRoutes = require('./appRoutes');
const userRoutes = require('./userRoutes');
const nodemailer = require('nodemailer');

const app = express();

// Set CORS options
const corsOptions = {
    origin: 'http://127.0.0.1:5500', // Your frontend's origin
    credentials: true, // Allow credentials to be sent
};

// Enable CORS with custom headers
app.use(cors(corsOptions));

// Middleware to parse cookies
app.use(cookieParser());

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session setup
app.use(session({
    secret: '123456789',
    resave: false,
    saveUninitialized: true,
    cookie: { 
        secure: false, // Set to true if using HTTPS
        httpOnly: true,
        sameSite: 'None' // Use 'Lax' for local development
    }
}));



// Use routes
app.use('/', authRoutes);
app.use('/', userRoutes);
app.use('/', appRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!' });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});

