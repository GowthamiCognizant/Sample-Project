const express = require('express');
const bcrypt = require('bcrypt');
const sql = require('mssql/msnodesqlv8');
const { poolPromise } = require('./db');
const nodemailer = require('nodemailer'); // For sending emails
require('dotenv').config();
const { google } = require('google-auth-library');
const router = express.Router();


// // Set up your OAuth2 credentials
// const CLIENT_ID = 'YOUR_GOOGLE_CLIENT_ID';
// const CLIENT_SECRET = 'YOUR_GOOGLE_CLIENT_SECRET';
// const REDIRECT_URI = 'YOUR_REDIRECT_URI';
// const REFRESH_TOKEN = 'YOUR_REFRESH_TOKEN';

// // Create a OAuth2 client
// const oAuth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);

// // Function to send emails
// async function sendEmail(to, subject, text) {
//     try {
//         const accessToken = await oAuth2Client.getAccessToken();

//         const transporter = nodemailer.createTransport({
//             service: 'gmail',
//             auth: {
//                 type: 'OAuth2',
//                 user: 'your-admin-email@gmail.com',  // Your admin Gmail
//                 clientId: CLIENT_ID,
//                 clientSecret: CLIENT_SECRET,
//                 refreshToken: REFRESH_TOKEN,
//                 accessToken: accessToken.token,
//             },
//         });

//         const mailOptions = {
//             from: 'your-admin-email@gmail.com',
//             to,
//             subject,
//             text,
//         };

//         const result = await transporter.sendMail(mailOptions);
//         return result;
//     } catch (error) {
//         throw new Error(`Error sending email: ${error.message}`);
//     }
// }

//**************************************************************

// // Set up your mail transporter (adjust this for your mail service)
// const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//         user: 'barathcts26@gmail.com',  // Admin email for sending confirmation
//         pass: 'uano xtdn dmkh ukjt'     // Admin email password (consider moving to environment variables for security)
//     }
// });




const transporter = nodemailer.createTransport({
    // host: process.env.SMTP_SERVER,
    // port: process.env.SMTP_PORT,
    host: 'apacsmtp.cts.com',
    port: 25,
    secure: false, // true for 465, false for other ports
    tls: {
        rejectUnauthorized: false, // Set to true in production
    },
    auth: {
        user: '2327204@cognizant.com',
        pass: '*************',
    },
    debug: true, // Show debug output
    connectionTimeout: 50000, // 45 seconds
    greetingTimeout: 50000,   // 45 seconds
    socketTimeout: 50000      // 45 seconds
});

transporter.verify(function(error, success) {
    if (error) {
        console.log('Error connecting to SMTP server:', error);
    } else {
        console.log('Server is ready to take messages:', success);
    }
});




// Helper function to send email to the admin with approval link
async function sendAdminApprovalLink(employeeID, email, adminEmail) {
    // Generate the approval link (for admin to confirm user signup)
    const approvalLink = `http://localhost:3000/admin/confirm-user?employeeID=${employeeID}&email=${email}`;
    
    // Generate role assignment links
    const editorLink = `http://localhost:3000/admin/assign-role?employeeID=${employeeID}&role=Editor`;
    const viewerLink = `http://localhost:3000/admin/assign-role?employeeID=${employeeID}&role=Viewer`;


    // Email content
    const emailContent = 
    `<p>A new user has signed up.</p>   
    <p> Employee ID: ${employeeID}</p>
    <p>Email: ${email}</p>
    <p>Please assign a role by clicking one of the buttons below:</p>
    
    <p><a href="${editorLink}">EDITOR</a></p>
    <p><a href="${viewerLink}">VIEWER</a></p>`;
    
    
    
    // Send the email

    try {
        const info = await transporter.sendMail({
            // from: 'barathcts26@gmail.com',  // Admin email
            from: '2327204@cognizant.com',
            to: adminEmail,  // Recipient (admin)
            subject: 'User Sign-Up Approval Needed',
            html: emailContent
        });
        console.log(`Approval link sent to admin: ${adminEmail}. Response: ${info.response}`);
    } catch (error) {
        console.error('Error sending approval link to admin:', error);
    }
}



// 1. Sign-up Route
router.post('/signup', async (req, res) => {
    const { employeeID, email, password } = req.body;

    console.log('Received signup request:', { employeeID, email });

    // Validate employee ID and email
    if (!employeeID || isNaN(employeeID)) {
        console.log('Validation error: Invalid EmployeeID');
        return res.status(400).json({ message: 'Invalid EmployeeID.' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        console.log('Validation error: Invalid email format');
        return res.status(400).json({ message: 'Invalid email format.' });
    }

    // Validate password length
    if (!password || password.length < 8) {
        console.log('Validation error: Password too short');
        return res.status(400).json({ message: 'Password must be at least 8 characters long.' });
    }

    try {
        const pool = await poolPromise;
        console.log('Database connection established.');

        // Hash the password before storing it
        const hashedPassword = await bcrypt.hash(password, 10);
        console.log('Password hashed successfully.');

        // Check if the employeeID already exists
        const checkQuery = 'SELECT EmployeeID FROM dbo.PendingUsers WHERE EmployeeID = @employeeID';
        const result = await pool.request()
            .input('employeeID', sql.Int, employeeID)
            .query(checkQuery);

        console.log('Checked for existing EmployeeID:', result.recordset.length > 0 ? 'Found' : 'Not found');

        if (result.recordset.length > 0) {
            // If the employeeID already exists, send an error message
            console.log('Validation error: EmployeeID already exists');
            return res.status(400).json({ message: 'EmployeeID already exists' });
        }

        // Insert user into PendingUsers table (awaiting admin confirmation)
        const insertQuery = `
            INSERT INTO PendingUsers (EmployeeID, Email, Password, Status) 
            VALUES (@employeeID, @Email, @Password, 'Pending')`;

        await pool.request()
            .input('employeeID', sql.Int, employeeID)
            .input('Email', sql.VarChar, email)
            .input('Password', sql.VarChar, hashedPassword)
            .query(insertQuery);
        
        console.log('User inserted into PendingUsers table.');

        // Query to get the admin email based on the role
        const adminEmailQuery = 'SELECT Email FROM dbo.Users WHERE Role = @role';
        const adminResult = await pool.request()
            .input('role', sql.VarChar, 'Super Admin')  // Assuming 'Role' is a varchar field
            .query(adminEmailQuery);

        console.log('Queried for admin email, result length:', adminResult.recordset.length);

        if (adminResult.recordset.length === 0) {
            console.log('Error: No admin found with the role Super Admin.');
            return res.status(500).json({ message: 'No admin found with the role Super Admin.' });
        }

        const adminEmail = adminResult.recordset[0].Email;  // Get the admin email from the result
        console.log('Admin email found:', adminEmail);

        // Send email to admin with confirmation link
        await sendAdminApprovalLink(employeeID, email, adminEmail);
        console.log('Admin approval link sent.');

        res.status(200).json({ message: 'Sign-up successful! Awaiting admin confirmation.' });

    } catch (error) {
        console.error('Error during sign-up:', error);
        res.status(500).json({ message: 'Error during sign-up process' });
    }
});



// 2. Role Assignment Route (Approval and Role Assignment Combined)
router.get('/admin/assign-role', async (req, res) => {
    const { employeeID, role } = req.query;

    // Validate role and employeeID
    if (!employeeID || !role) {
        return res.status(400).send('EmployeeID and Role are required.');
    }

    try {
        const pool = await poolPromise;

        // Move user from PendingUsers to Users table and assign role
        const moveUserQuery = `
            INSERT INTO Users (EmployeeID, Email, Password, Role)
            SELECT EmployeeID, Email, Password, @role FROM PendingUsers 
            WHERE EmployeeID = @employeeID;
            DELETE FROM PendingUsers WHERE EmployeeID = @employeeID;`;

        await pool.request()
            .input('employeeID', sql.Int, employeeID)
            .input('role', sql.VarChar, role)
            .query(moveUserQuery);

        // Query to get the user's email after moving to Users table
        const userEmailQuery = 'SELECT Email FROM Users WHERE EmployeeID = @employeeID';
        const userResult = await pool.request()
            .input('employeeID', sql.Int, employeeID)
            .query(userEmailQuery);

        const userEmail = userResult.recordset[0].Email;

        // Send email to the user confirming they can log in
        const emailContent = `
            <p>Congratulations! Your registration has been approved. 
            You have been assigned the role of <strong>${role}</strong>.</p>
            <p>You can now log in to the application using the link below:</p>
            <p><a href="http://127.0.0.1:5500/HondaKITE/HondaKITE/login.html">Login Page</a></p>`;

        await transporter.sendMail({
            //from: 'barathcts26@gmail.com',  // Admin email
            from: process.env.EMAIL_USER,
            to: userEmail,  // Recipient (user)
            subject: 'Sign-Up Approved: You Can Now Log In',
            html: emailContent // Changed to html for styling
        });

        res.status(200).send(`User approved and Role assigned as <strong>${role}</strong> for Employee ID <strong>${employeeID}</strong>. Email sent to the user.`);
    } catch (error) {
        console.error('Error during role assignment and user approval:', error);
        res.status(500).send('Error during role assignment and user approval.');
    }
});

// Login Route
router.post('/login', async (req, res) => {
    const { employeeID, email, password } = req.body;

    console.log(`Login attempt with employeeID: ${employeeID}, email: ${email}`);

    if (!employeeID || !email || !password) {
        return res.status(400).json({ message: 'EmployeeID, Email, and Password are required.' });
    }

    try {
        const pool = await poolPromise;

        // Query the Users table for employeeID and email (only approved users)
        const query = `SELECT * FROM Users WHERE EmployeeID = @employeeID AND Email = @Email`;
        const result = await pool.request()
            .input('employeeID', sql.Int, employeeID)
            .input('Email', sql.VarChar, email)
            .query(query);

        // Check if the result is empty
        if (result.recordset.length === 0) {
            return res.status(404).json({ message: 'EmployeeID or Email not found.' });
        }

        const user = result.recordset[0];

        // Check if the password is valid
        const isPasswordValid = await bcrypt.compare(password, user.Password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Invalid password.' });
        }

        // Store/set session after successful login
        req.session.employeeID = user.EmployeeID;
        req.session.role = user.Role; // Assuming there's a role field in the DB
        req.session.save();

        console.log('User logged in:', user); // Log user details

        res.status(200).json({     // Send back user role to the frontend
            message: 'Login successful',
            role: user.Role
        });

    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ message: 'Error during login.' });
    }
});

module.exports = router;


