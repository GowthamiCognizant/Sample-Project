var elementsCss = 'body{font-family:monospace}b{position:relative;color:#fff;margin:15px 15px 15px 40px;font-size:20px}hr{position:relative;margin:40px 0;width:100%;border-top:4px solid #fff}h1{position:relative;width:auto;text-align:center;font-weight:lighter;color:#fff;font-size:50px;margin-top:40px;text-shadow:2.5px 2.5px 1px #b61924}.styled-table{position:relative;border-collapse:collapse;margin:15px 15px 15px 40px;font-size:15px;min-width:400px;box-shadow:0 0 20px rgba(0,0,0,.15)}.styled-table thead tr{background-color:#b61924;color:#fff;text-align:left}.styled-table td,.styled-table th{padding:12px 15px}.styled-table tbody tr{border-bottom:1px solid #ddd;font-size:15px}.styled-table tbody tr:nth-of-type(even){background-color:#f3f3f3}.styled-table tbody tr:nth-of-type(odd){background-color:#fff}.styled-table tbody tr:last-of-type{border-bottom:2px solid #b61924}#viewAllSelectors{z-index:1;cursor:pointer;position:fixed;right:60px;top:60px;border:none;background:#b61924;color:#fff;font-weight:100;padding:20px;text-transform:uppercase;border-radius:6px;display:inline-block;transition:all .3s ease 0s;-webkit-box-shadow:0 5px 40px -10px rgba(0,0,0,.57);-moz-box-shadow:0 5px 40px -10px rgba(0,0,0,.57)}#viewAllSelectors:hover{font-weight:700;letter-spacing:3px}#viewAllSelectors:disabled{background:#696969;cursor:not-allowed;font-weight:100;letter-spacing:0}';
var bgAnimationCss = '#particles-js{top:0;left:0;bottom:0;right:0;position:fixed;width:100%;height:100%;background:#00356b}';
var bgAnimationScript = 'function hexToRgb(e){e=e.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i,function(e,a,t,i){return a+a+t+t+i+i});var a=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(e);return a?{r:parseInt(a[1],16),g:parseInt(a[2],16),b:parseInt(a[3],16)}:null}function clamp(e,a,t){return Math.min(Math.max(e,a),t)}function isInArray(e,a){return a.indexOf(e)>-1}var pJS=function(e,a){var t=document.querySelector("#"+e+" > .particles-js-canvas-el");this.pJS={canvas:{el:t,w:t.offsetWidth,h:t.offsetHeight},particles:{number:{value:400,density:{enable:!0,value_area:800}},color:{value:"#fff"},shape:{type:"circle",stroke:{width:0,color:"#ff0000"},polygon:{nb_sides:5},image:{src:"",width:100,height:100}},opacity:{value:1,random:!1,anim:{enable:!1,speed:2,opacity_min:0,sync:!1}},size:{value:20,random:!1,anim:{enable:!1,speed:20,size_min:0,sync:!1}},line_linked:{enable:!0,distance:100,color:"#fff",opacity:1,width:1},move:{enable:!0,speed:2,direction:"none",random:!1,straight:!1,out_mode:"out",bounce:!1,attract:{enable:!1,rotateX:3e3,rotateY:3e3}},array:[]},interactivity:{detect_on:"canvas",events:{onhover:{enable:!0,mode:"grab"},onclick:{enable:!0,mode:"push"},resize:!0},modes:{grab:{distance:100,line_linked:{opacity:1}},bubble:{distance:200,size:80,duration:.4},repulse:{distance:200,duration:.4},push:{particles_nb:4},remove:{particles_nb:2}},mouse:{}},retina_detect:!1,fn:{interact:{},modes:{},vendors:{}},tmp:{}};var i=this.pJS;a&&Object.deepExtend(i,a),i.tmp.obj={size_value:i.particles.size.value,size_anim_speed:i.particles.size.anim.speed,move_speed:i.particles.move.speed,line_linked_distance:i.particles.line_linked.distance,line_linked_width:i.particles.line_linked.width,mode_grab_distance:i.interactivity.modes.grab.distance,mode_bubble_distance:i.interactivity.modes.bubble.distance,mode_bubble_size:i.interactivity.modes.bubble.size,mode_repulse_distance:i.interactivity.modes.repulse.distance},i.fn.retinaInit=function(){i.retina_detect&&window.devicePixelRatio>1?(i.canvas.pxratio=window.devicePixelRatio,i.tmp.retina=!0):(i.canvas.pxratio=1,i.tmp.retina=!1),i.canvas.w=i.canvas.el.offsetWidth*i.canvas.pxratio,i.canvas.h=i.canvas.el.offsetHeight*i.canvas.pxratio,i.particles.size.value=i.tmp.obj.size_value*i.canvas.pxratio,i.particles.size.anim.speed=i.tmp.obj.size_anim_speed*i.canvas.pxratio,i.particles.move.speed=i.tmp.obj.move_speed*i.canvas.pxratio,i.particles.line_linked.distance=i.tmp.obj.line_linked_distance*i.canvas.pxratio,i.interactivity.modes.grab.distance=i.tmp.obj.mode_grab_distance*i.canvas.pxratio,i.interactivity.modes.bubble.distance=i.tmp.obj.mode_bubble_distance*i.canvas.pxratio,i.particles.line_linked.width=i.tmp.obj.line_linked_width*i.canvas.pxratio,i.interactivity.modes.bubble.size=i.tmp.obj.mode_bubble_size*i.canvas.pxratio,i.interactivity.modes.repulse.distance=i.tmp.obj.mode_repulse_distance*i.canvas.pxratio},i.fn.canvasInit=function(){i.canvas.ctx=i.canvas.el.getContext("2d")},i.fn.canvasSize=function(){i.canvas.el.width=i.canvas.w,i.canvas.el.height=i.canvas.h,i&&i.interactivity.events.resize&&window.addEventListener("resize",function(){i.canvas.w=i.canvas.el.offsetWidth,i.canvas.h=i.canvas.el.offsetHeight,i.tmp.retina&&(i.canvas.w*=i.canvas.pxratio,i.canvas.h*=i.canvas.pxratio),i.canvas.el.width=i.canvas.w,i.canvas.el.height=i.canvas.h,i.particles.move.enable||(i.fn.particlesEmpty(),i.fn.particlesCreate(),i.fn.particlesDraw(),i.fn.vendors.densityAutoParticles()),i.fn.vendors.densityAutoParticles()})},i.fn.canvasPaint=function(){i.canvas.ctx.fillRect(0,0,i.canvas.w,i.canvas.h)},i.fn.canvasClear=function(){i.canvas.ctx.clearRect(0,0,i.canvas.w,i.canvas.h)},i.fn.particle=function(e,a,t){if(this.radius=(i.particles.size.random?Math.random():1)*i.particles.size.value,i.particles.size.anim.enable&&(this.size_status=!1,this.vs=i.particles.size.anim.speed/100,i.particles.size.anim.sync||(this.vs=this.vs*Math.random())),this.x=t?t.x:Math.random()*i.canvas.w,this.y=t?t.y:Math.random()*i.canvas.h,this.x>i.canvas.w-2*this.radius?this.x=this.x-this.radius:this.x<2*this.radius&&(this.x=this.x+this.radius),this.y>i.canvas.h-2*this.radius?this.y=this.y-this.radius:this.y<2*this.radius&&(this.y=this.y+this.radius),i.particles.move.bounce&&i.fn.vendors.checkOverlap(this,t),this.color={},"object"==typeof e.value)if(e.value instanceof Array){var n=e.value[Math.floor(Math.random()*i.particles.color.value.length)];this.color.rgb=hexToRgb(n)}else null!=e.value.r&&null!=e.value.g&&null!=e.value.b&&(this.color.rgb={r:e.value.r,g:e.value.g,b:e.value.b}),null!=e.value.h&&null!=e.value.s&&null!=e.value.l&&(this.color.hsl={h:e.value.h,s:e.value.s,l:e.value.l});else"random"==e.value?this.color.rgb={r:Math.floor(256*Math.random())+0,g:Math.floor(256*Math.random())+0,b:Math.floor(256*Math.random())+0}:"string"==typeof e.value&&(this.color=e,this.color.rgb=hexToRgb(this.color.value));this.opacity=(i.particles.opacity.random?Math.random():1)*i.particles.opacity.value,i.particles.opacity.anim.enable&&(this.opacity_status=!1,this.vo=i.particles.opacity.anim.speed/100,i.particles.opacity.anim.sync||(this.vo=this.vo*Math.random()));var s={};switch(i.particles.move.direction){case"top":s={x:0,y:-1};break;case"top-right":s={x:.5,y:-.5};break;case"right":s={x:1,y:-0};break;case"bottom-right":s={x:.5,y:.5};break;case"bottom":s={x:0,y:1};break;case"bottom-left":s={x:-.5,y:1};break;case"left":s={x:-1,y:0};break;case"top-left":s={x:-.5,y:-.5};break;default:s={x:0,y:0}}i.particles.move.straight?(this.vx=s.x,this.vy=s.y,i.particles.move.random&&(this.vx=this.vx*Math.random(),this.vy=this.vy*Math.random())):(this.vx=s.x+Math.random()-.5,this.vy=s.y+Math.random()-.5),this.vx_i=this.vx,this.vy_i=this.vy;var r=i.particles.shape.type;if("object"==typeof r){if(r instanceof Array){var c=r[Math.floor(Math.random()*r.length)];this.shape=c}}else this.shape=r;if("image"==this.shape){var o=i.particles.shape;this.img={src:o.image.src,ratio:o.image.width/o.image.height},this.img.ratio||(this.img.ratio=1),"svg"==i.tmp.img_type&&null!=i.tmp.source_svg&&(i.fn.vendors.createSvgImg(this),i.tmp.pushing&&(this.img.loaded=!1))}},i.fn.particle.prototype.draw=function(){var e=this;if(null!=e.radius_bubble)var a=e.radius_bubble;else a=e.radius;if(null!=e.opacity_bubble)var t=e.opacity_bubble;else t=e.opacity;if(e.color.rgb)var n="rgba("+e.color.rgb.r+","+e.color.rgb.g+","+e.color.rgb.b+","+t+")";else n="hsla("+e.color.hsl.h+","+e.color.hsl.s+"%,"+e.color.hsl.l+"%,"+t+")";switch(i.canvas.ctx.fillStyle=n,i.canvas.ctx.beginPath(),e.shape){case"circle":i.canvas.ctx.arc(e.x,e.y,a,0,2*Math.PI,!1);break;case"edge":i.canvas.ctx.rect(e.x-a,e.y-a,2*a,2*a);break;case"triangle":i.fn.vendors.drawShape(i.canvas.ctx,e.x-a,e.y+a/1.66,2*a,3,2);break;case"polygon":i.fn.vendors.drawShape(i.canvas.ctx,e.x-a/(i.particles.shape.polygon.nb_sides/3.5),e.y-a/.76,2.66*a/(i.particles.shape.polygon.nb_sides/3),i.particles.shape.polygon.nb_sides,1);break;case"star":i.fn.vendors.drawShape(i.canvas.ctx,e.x-2*a/(i.particles.shape.polygon.nb_sides/4),e.y-a/1.52,2*a*2.66/(i.particles.shape.polygon.nb_sides/3),i.particles.shape.polygon.nb_sides,2);break;case"image":if("svg"==i.tmp.img_type)var s=e.img.obj;else s=i.tmp.img_obj;s&&i.canvas.ctx.drawImage(s,e.x-a,e.y-a,2*a,2*a/e.img.ratio)}i.canvas.ctx.closePath(),i.particles.shape.stroke.width>0&&(i.canvas.ctx.strokeStyle=i.particles.shape.stroke.color,i.canvas.ctx.lineWidth=i.particles.shape.stroke.width,i.canvas.ctx.stroke()),i.canvas.ctx.fill()},i.fn.particlesCreate=function(){for(var e=0;e<i.particles.number.value;e++)i.particles.array.push(new i.fn.particle(i.particles.color,i.particles.opacity.value))},i.fn.particlesUpdate=function(){for(var e=0;e<i.particles.array.length;e++){var a=i.particles.array[e];if(i.particles.move.enable){var t=i.particles.move.speed/2;a.x+=a.vx*t,a.y+=a.vy*t}if(i.particles.opacity.anim.enable&&(1==a.opacity_status?(a.opacity>=i.particles.opacity.value&&(a.opacity_status=!1),a.opacity+=a.vo):(a.opacity<=i.particles.opacity.anim.opacity_min&&(a.opacity_status=!0),a.opacity-=a.vo),a.opacity<0&&(a.opacity=0)),i.particles.size.anim.enable&&(1==a.size_status?(a.radius>=i.particles.size.value&&(a.size_status=!1),a.radius+=a.vs):(a.radius<=i.particles.size.anim.size_min&&(a.size_status=!0),a.radius-=a.vs),a.radius<0&&(a.radius=0)),"bounce"==i.particles.move.out_mode)var n={x_left:a.radius,x_right:i.canvas.w,y_top:a.radius,y_bottom:i.canvas.h};else n={x_left:-a.radius,x_right:i.canvas.w+a.radius,y_top:-a.radius,y_bottom:i.canvas.h+a.radius};switch(a.x-a.radius>i.canvas.w?(a.x=n.x_left,a.y=Math.random()*i.canvas.h):a.x+a.radius<0&&(a.x=n.x_right,a.y=Math.random()*i.canvas.h),a.y-a.radius>i.canvas.h?(a.y=n.y_top,a.x=Math.random()*i.canvas.w):a.y+a.radius<0&&(a.y=n.y_bottom,a.x=Math.random()*i.canvas.w),i.particles.move.out_mode){case"bounce":a.x+a.radius>i.canvas.w?a.vx=-a.vx:a.x-a.radius<0&&(a.vx=-a.vx),a.y+a.radius>i.canvas.h?a.vy=-a.vy:a.y-a.radius<0&&(a.vy=-a.vy)}if(isInArray("grab",i.interactivity.events.onhover.mode)&&i.fn.modes.grabParticle(a),(isInArray("bubble",i.interactivity.events.onhover.mode)||isInArray("bubble",i.interactivity.events.onclick.mode))&&i.fn.modes.bubbleParticle(a),(isInArray("repulse",i.interactivity.events.onhover.mode)||isInArray("repulse",i.interactivity.events.onclick.mode))&&i.fn.modes.repulseParticle(a),i.particles.line_linked.enable||i.particles.move.attract.enable)for(var s=e+1;s<i.particles.array.length;s++){var r=i.particles.array[s];i.particles.line_linked.enable&&i.fn.interact.linkParticles(a,r),i.particles.move.attract.enable&&i.fn.interact.attractParticles(a,r),i.particles.move.bounce&&i.fn.interact.bounceParticles(a,r)}}},i.fn.particlesDraw=function(){i.canvas.ctx.clearRect(0,0,i.canvas.w,i.canvas.h),i.fn.particlesUpdate();for(var e=0;e<i.particles.array.length;e++){i.particles.array[e].draw()}},i.fn.particlesEmpty=function(){i.particles.array=[]},i.fn.particlesRefresh=function(){cancelRequestAnimFrame(i.fn.checkAnimFrame),cancelRequestAnimFrame(i.fn.drawAnimFrame),i.tmp.source_svg=void 0,i.tmp.img_obj=void 0,i.tmp.count_svg=0,i.fn.particlesEmpty(),i.fn.canvasClear(),i.fn.vendors.start()},i.fn.interact.linkParticles=function(e,a){var t=e.x-a.x,n=e.y-a.y,s=Math.sqrt(t*t+n*n);if(s<=i.particles.line_linked.distance){var r=i.particles.line_linked.opacity-s/(1/i.particles.line_linked.opacity)/i.particles.line_linked.distance;if(r>0){var c=i.particles.line_linked.color_rgb_line;i.canvas.ctx.strokeStyle="rgba("+c.r+","+c.g+","+c.b+","+r+")",i.canvas.ctx.lineWidth=i.particles.line_linked.width,i.canvas.ctx.beginPath(),i.canvas.ctx.moveTo(e.x,e.y),i.canvas.ctx.lineTo(a.x,a.y),i.canvas.ctx.stroke(),i.canvas.ctx.closePath()}}},i.fn.interact.attractParticles=function(e,a){var t=e.x-a.x,n=e.y-a.y;if(Math.sqrt(t*t+n*n)<=i.particles.line_linked.distance){var s=t/(1e3*i.particles.move.attract.rotateX),r=n/(1e3*i.particles.move.attract.rotateY);e.vx-=s,e.vy-=r,a.vx+=s,a.vy+=r}},i.fn.interact.bounceParticles=function(e,a){var t=e.x-a.x,i=e.y-a.y,n=Math.sqrt(t*t+i*i);e.radius+a.radius>=n&&(e.vx=-e.vx,e.vy=-e.vy,a.vx=-a.vx,a.vy=-a.vy)},i.fn.modes.pushParticles=function(e,a){i.tmp.pushing=!0;for(var t=0;e>t;t++)i.particles.array.push(new i.fn.particle(i.particles.color,i.particles.opacity.value,{x:a?a.pos_x:Math.random()*i.canvas.w,y:a?a.pos_y:Math.random()*i.canvas.h})),t==e-1&&(i.particles.move.enable||i.fn.particlesDraw(),i.tmp.pushing=!1)},i.fn.modes.removeParticles=function(e){i.particles.array.splice(0,e),i.particles.move.enable||i.fn.particlesDraw()},i.fn.modes.bubbleParticle=function(e){function a(){e.opacity_bubble=e.opacity,e.radius_bubble=e.radius}function t(a,t,n,s,r){if(a!=t)if(i.tmp.bubble_duration_end){if(null!=n)o=a+(a-(s-p*(s-a)/i.interactivity.modes.bubble.duration)),"size"==r&&(e.radius_bubble=o),"opacity"==r&&(e.opacity_bubble=o)}else if(v<=i.interactivity.modes.bubble.distance){if(null!=n)var c=n;else c=s;if(c!=a){var o=s-p*(s-a)/i.interactivity.modes.bubble.duration;"size"==r&&(e.radius_bubble=o),"opacity"==r&&(e.opacity_bubble=o)}}else"size"==r&&(e.radius_bubble=void 0),"opacity"==r&&(e.opacity_bubble=void 0)}if(i.interactivity.events.onhover.enable&&isInArray("bubble",i.interactivity.events.onhover.mode)){var n=e.x-i.interactivity.mouse.pos_x,s=e.y-i.interactivity.mouse.pos_y,r=1-(v=Math.sqrt(n*n+s*s))/i.interactivity.modes.bubble.distance;if(v<=i.interactivity.modes.bubble.distance){if(r>=0&&"mousemove"==i.interactivity.status){if(i.interactivity.modes.bubble.size!=i.particles.size.value)if(i.interactivity.modes.bubble.size>i.particles.size.value){(o=e.radius+i.interactivity.modes.bubble.size*r)>=0&&(e.radius_bubble=o)}else{var c=e.radius-i.interactivity.modes.bubble.size,o=e.radius-c*r;e.radius_bubble=o>0?o:0}if(i.interactivity.modes.bubble.opacity!=i.particles.opacity.value)if(i.interactivity.modes.bubble.opacity>i.particles.opacity.value){(l=i.interactivity.modes.bubble.opacity*r)>e.opacity&&l<=i.interactivity.modes.bubble.opacity&&(e.opacity_bubble=l)}else{var l;(l=e.opacity-(i.particles.opacity.value-i.interactivity.modes.bubble.opacity)*r)<e.opacity&&l>=i.interactivity.modes.bubble.opacity&&(e.opacity_bubble=l)}}}else a();"mouseleave"==i.interactivity.status&&a()}else if(i.interactivity.events.onclick.enable&&isInArray("bubble",i.interactivity.events.onclick.mode)){if(i.tmp.bubble_clicking){n=e.x-i.interactivity.mouse.click_pos_x,s=e.y-i.interactivity.mouse.click_pos_y;var v=Math.sqrt(n*n+s*s),p=((new Date).getTime()-i.interactivity.mouse.click_time)/1e3;p>i.interactivity.modes.bubble.duration&&(i.tmp.bubble_duration_end=!0),p>2*i.interactivity.modes.bubble.duration&&(i.tmp.bubble_clicking=!1,i.tmp.bubble_duration_end=!1)}i.tmp.bubble_clicking&&(t(i.interactivity.modes.bubble.size,i.particles.size.value,e.radius_bubble,e.radius,"size"),t(i.interactivity.modes.bubble.opacity,i.particles.opacity.value,e.opacity_bubble,e.opacity,"opacity"))}},i.fn.modes.repulseParticle=function(e){if(i.interactivity.events.onhover.enable&&isInArray("repulse",i.interactivity.events.onhover.mode)&&"mousemove"==i.interactivity.status){var a=e.x-i.interactivity.mouse.pos_x,t=e.y-i.interactivity.mouse.pos_y,n=Math.sqrt(a*a+t*t),s={x:a/n,y:t/n},r=clamp(1/(o=i.interactivity.modes.repulse.distance)*(-1*Math.pow(n/o,2)+1)*o*100,0,50),c={x:e.x+s.x*r,y:e.y+s.y*r};"bounce"==i.particles.move.out_mode?(c.x-e.radius>0&&c.x+e.radius<i.canvas.w&&(e.x=c.x),c.y-e.radius>0&&c.y+e.radius<i.canvas.h&&(e.y=c.y)):(e.x=c.x,e.y=c.y)}else if(i.interactivity.events.onclick.enable&&isInArray("repulse",i.interactivity.events.onclick.mode))if(i.tmp.repulse_finish||(i.tmp.repulse_count++,i.tmp.repulse_count==i.particles.array.length&&(i.tmp.repulse_finish=!0)),i.tmp.repulse_clicking){var o=Math.pow(i.interactivity.modes.repulse.distance/6,3),l=i.interactivity.mouse.click_pos_x-e.x,v=i.interactivity.mouse.click_pos_y-e.y,p=l*l+v*v,d=-o/p*1;o>=p&&function(){var a=Math.atan2(v,l);if(e.vx=d*Math.cos(a),e.vy=d*Math.sin(a),"bounce"==i.particles.move.out_mode){var t={x:e.x+e.vx,y:e.y+e.vy};t.x+e.radius>i.canvas.w?e.vx=-e.vx:t.x-e.radius<0&&(e.vx=-e.vx),t.y+e.radius>i.canvas.h?e.vy=-e.vy:t.y-e.radius<0&&(e.vy=-e.vy)}}()}else 0==i.tmp.repulse_clicking&&(e.vx=e.vx_i,e.vy=e.vy_i)},i.fn.modes.grabParticle=function(e){if(i.interactivity.events.onhover.enable&&"mousemove"==i.interactivity.status){var a=e.x-i.interactivity.mouse.pos_x,t=e.y-i.interactivity.mouse.pos_y,n=Math.sqrt(a*a+t*t);if(n<=i.interactivity.modes.grab.distance){var s=i.interactivity.modes.grab.line_linked.opacity-n/(1/i.interactivity.modes.grab.line_linked.opacity)/i.interactivity.modes.grab.distance;if(s>0){var r=i.particles.line_linked.color_rgb_line;i.canvas.ctx.strokeStyle="rgba("+r.r+","+r.g+","+r.b+","+s+")",i.canvas.ctx.lineWidth=i.particles.line_linked.width,i.canvas.ctx.beginPath(),i.canvas.ctx.moveTo(e.x,e.y),i.canvas.ctx.lineTo(i.interactivity.mouse.pos_x,i.interactivity.mouse.pos_y),i.canvas.ctx.stroke(),i.canvas.ctx.closePath()}}}},i.fn.vendors.eventsListeners=function(){"window"==i.interactivity.detect_on?i.interactivity.el=window:i.interactivity.el=i.canvas.el,(i.interactivity.events.onhover.enable||i.interactivity.events.onclick.enable)&&(i.interactivity.el.addEventListener("mousemove",function(e){if(i.interactivity.el==window)var a=e.clientX,t=e.clientY;else a=e.offsetX||e.clientX,t=e.offsetY||e.clientY;i.interactivity.mouse.pos_x=a,i.interactivity.mouse.pos_y=t,i.tmp.retina&&(i.interactivity.mouse.pos_x*=i.canvas.pxratio,i.interactivity.mouse.pos_y*=i.canvas.pxratio),i.interactivity.status="mousemove"}),i.interactivity.el.addEventListener("mouseleave",function(e){i.interactivity.mouse.pos_x=null,i.interactivity.mouse.pos_y=null,i.interactivity.status="mouseleave"})),i.interactivity.events.onclick.enable&&i.interactivity.el.addEventListener("click",function(){if(i.interactivity.mouse.click_pos_x=i.interactivity.mouse.pos_x,i.interactivity.mouse.click_pos_y=i.interactivity.mouse.pos_y,i.interactivity.mouse.click_time=(new Date).getTime(),i.interactivity.events.onclick.enable)switch(i.interactivity.events.onclick.mode){case"push":i.particles.move.enable?i.fn.modes.pushParticles(i.interactivity.modes.push.particles_nb,i.interactivity.mouse):1==i.interactivity.modes.push.particles_nb?i.fn.modes.pushParticles(i.interactivity.modes.push.particles_nb,i.interactivity.mouse):i.interactivity.modes.push.particles_nb>1&&i.fn.modes.pushParticles(i.interactivity.modes.push.particles_nb);break;case"remove":i.fn.modes.removeParticles(i.interactivity.modes.remove.particles_nb);break;case"bubble":i.tmp.bubble_clicking=!0;break;case"repulse":i.tmp.repulse_clicking=!0,i.tmp.repulse_count=0,i.tmp.repulse_finish=!1,setTimeout(function(){i.tmp.repulse_clicking=!1},1e3*i.interactivity.modes.repulse.duration)}})},i.fn.vendors.densityAutoParticles=function(){if(i.particles.number.density.enable){var e=i.canvas.el.width*i.canvas.el.height/1e3;i.tmp.retina&&(e/=2*i.canvas.pxratio);var a=e*i.particles.number.value/i.particles.number.density.value_area,t=i.particles.array.length-a;0>t?i.fn.modes.pushParticles(Math.abs(t)):i.fn.modes.removeParticles(t)}},i.fn.vendors.checkOverlap=function(e,a){for(var t=0;t<i.particles.array.length;t++){var n=i.particles.array[t],s=e.x-n.x,r=e.y-n.y;Math.sqrt(s*s+r*r)<=e.radius+n.radius&&(e.x=a?a.x:Math.random()*i.canvas.w,e.y=a?a.y:Math.random()*i.canvas.h,i.fn.vendors.checkOverlap(e))}},i.fn.vendors.createSvgImg=function(e){var a=i.tmp.source_svg.replace(/#([0-9A-F]{3,6})/gi,function(a,t,i,n){if(e.color.rgb)var s="rgba("+e.color.rgb.r+","+e.color.rgb.g+","+e.color.rgb.b+","+e.opacity+")";else s="hsla("+e.color.hsl.h+","+e.color.hsl.s+"%,"+e.color.hsl.l+"%,"+e.opacity+")";return s}),t=new Blob([a],{type:"image/svg+xml;charset=utf-8"}),n=window.URL||window.webkitURL||window,s=n.createObjectURL(t),r=new Image;r.addEventListener("load",function(){e.img.obj=r,e.img.loaded=!0,n.revokeObjectURL(s),i.tmp.count_svg++}),r.src=s},i.fn.vendors.destroypJS=function(){cancelAnimationFrame(i.fn.drawAnimFrame),t.remove(),pJSDom=null},i.fn.vendors.drawShape=function(e,a,t,i,n,s){var r=n*s,c=n/s,o=180*(c-2)/c,l=Math.PI-Math.PI*o/180;e.save(),e.beginPath(),e.translate(a,t),e.moveTo(0,0);for(var v=0;r>v;v++)e.lineTo(i,0),e.translate(i,0),e.rotate(l);e.fill(),e.restore()},i.fn.vendors.exportImg=function(){window.open(i.canvas.el.toDataURL("image/png"),"_blank")},i.fn.vendors.loadImg=function(e){if(i.tmp.img_error=void 0,""!=i.particles.shape.image.src)if("svg"==e){var a=new XMLHttpRequest;a.open("GET",i.particles.shape.image.src),a.onreadystatechange=function(e){4==a.readyState&&(200==a.status?(i.tmp.source_svg=e.currentTarget.response,i.fn.vendors.checkBeforeDraw()):(console.log("Error pJS - Image not found"),i.tmp.img_error=!0))},a.send()}else{var t=new Image;t.addEventListener("load",function(){i.tmp.img_obj=t,i.fn.vendors.checkBeforeDraw()}),t.src=i.particles.shape.image.src}else console.log("Error pJS - No image.src"),i.tmp.img_error=!0},i.fn.vendors.draw=function(){"image"==i.particles.shape.type?"svg"==i.tmp.img_type?i.tmp.count_svg>=i.particles.number.value?(i.fn.particlesDraw(),i.particles.move.enable?i.fn.drawAnimFrame=requestAnimFrame(i.fn.vendors.draw):cancelRequestAnimFrame(i.fn.drawAnimFrame)):i.tmp.img_error||(i.fn.drawAnimFrame=requestAnimFrame(i.fn.vendors.draw)):null!=i.tmp.img_obj?(i.fn.particlesDraw(),i.particles.move.enable?i.fn.drawAnimFrame=requestAnimFrame(i.fn.vendors.draw):cancelRequestAnimFrame(i.fn.drawAnimFrame)):i.tmp.img_error||(i.fn.drawAnimFrame=requestAnimFrame(i.fn.vendors.draw)):(i.fn.particlesDraw(),i.particles.move.enable?i.fn.drawAnimFrame=requestAnimFrame(i.fn.vendors.draw):cancelRequestAnimFrame(i.fn.drawAnimFrame))},i.fn.vendors.checkBeforeDraw=function(){"image"==i.particles.shape.type?"svg"==i.tmp.img_type&&null==i.tmp.source_svg?i.tmp.checkAnimFrame=requestAnimFrame(check):(cancelRequestAnimFrame(i.tmp.checkAnimFrame),i.tmp.img_error||(i.fn.vendors.init(),i.fn.vendors.draw())):(i.fn.vendors.init(),i.fn.vendors.draw())},i.fn.vendors.init=function(){i.fn.retinaInit(),i.fn.canvasInit(),i.fn.canvasSize(),i.fn.canvasPaint(),i.fn.particlesCreate(),i.fn.vendors.densityAutoParticles(),i.particles.line_linked.color_rgb_line=hexToRgb(i.particles.line_linked.color)},i.fn.vendors.start=function(){isInArray("image",i.particles.shape.type)?(i.tmp.img_type=i.particles.shape.image.src.substr(i.particles.shape.image.src.length-3),i.fn.vendors.loadImg(i.tmp.img_type)):i.fn.vendors.checkBeforeDraw()},i.fn.vendors.eventsListeners(),i.fn.vendors.start()};Object.deepExtend=function(e,a){for(var t in a)a[t]&&a[t].constructor&&a[t].constructor===Object?(e[t]=e[t]||{},arguments.callee(e[t],a[t])):e[t]=a[t];return e},window.requestAnimFrame=window.requestAnimationFrame||window.webkitRequestAnimationFrame||window.mozRequestAnimationFrame||window.oRequestAnimationFrame||window.msRequestAnimationFrame||function(e){window.setTimeout(e,1e3/60)},window.cancelRequestAnimFrame=window.cancelAnimationFrame||window.webkitCancelRequestAnimationFrame||window.mozCancelRequestAnimationFrame||window.oCancelRequestAnimationFrame||window.msCancelRequestAnimationFrame||clearTimeout,window.pJSDom=[],window.particlesJS=function(e,a){"string"!=typeof e&&(a=e,e="particles-js"),e||(e="particles-js");var t=document.getElementById(e),i="particles-js-canvas-el",n=t.getElementsByClassName(i);if(n.length)for(;n.length>0;)t.removeChild(n[0]);var s=document.createElement("canvas");s.className=i,s.style.width="100%",s.style.height="100%",null!=document.getElementById(e).appendChild(s)&&pJSDom.push(new pJS(e,a))},window.particlesJS.load=function(e,a,t){var i=new XMLHttpRequest;i.open("GET",a),i.onreadystatechange=function(a){if(4==i.readyState)if(200==i.status){var n=JSON.parse(a.currentTarget.response);window.particlesJS(e,n),t&&t()}else console.log("Error pJS - XMLHttpRequest status: "+i.status),console.log("Error pJS - File config not found")},i.send()},particlesJS("particles-js",{particles:{number:{value:80,density:{enable:!0,value_area:700}},color:{value:"#ffffff"},shape:{type:"circle",stroke:{width:0,color:"#000000"},polygon:{nb_sides:5}},opacity:{value:.5,random:!1,anim:{enable:!1,speed:.1,opacity_min:.1,sync:!1}},size:{value:3,random:!0,anim:{enable:!1,speed:10,size_min:.1,sync:!1}},line_linked:{enable:!0,distance:150,color:"#ffffff",opacity:.4,width:1},move:{enable:!0,speed:2,direction:"none",random:!1,straight:!1,out_mode:"out",bounce:!1,attract:{enable:!1,rotateX:600,rotateY:1200}}},interactivity:{detect_on:"canvas",events:{onhover:{enable:!0,mode:"grab"},onclick:{enable:!0,mode:"push"},resize:!0},modes:{grab:{distance:140,line_linked:{opacity:1}},bubble:{distance:400,size:40,duration:2,opacity:8,speed:3},repulse:{distance:200,duration:.4},push:{particles_nb:4},remove:{particles_nb:2}}},retina_detect:!0});';
var frameWarningCss = '#frameWarning{position:relative;padding:20px;color:#fff;opacity:1;transition:opacity .6s;margin-bottom:15px;background-color:#ff9800}#closeframeWarning{margin-left:15px;color:#fff;font-weight:700;float:right;font-size:22px;line-height:20px;cursor:pointer;transition:.3s}#closeframeWarning:hover{color:#000}';
var frameWarningScript = 'document.getElementById("closeframeWarning").onclick=function(){var e=this.parentElement;e.style.opacity="0",setTimeout(function(){e.style.display="none"},600)};';
var modelDialogCss = ':root{--lightgray:#efefef;--blue:steelblue;--white:#fff;--black:rgba(0, 0, 0, 0.8);--bounceEasing:cubic-bezier(0.51, 0.92, 0.24, 1.15)}.modal{z-index:10;position:fixed;top:0;left:0;right:0;bottom:0;display:flex;align-items:center;justify-content:center;padding:1rem;background:var(--black);cursor:pointer;visibility:hidden;opacity:0;transition:all .35s ease-in}.modal.is-visible{visibility:visible;opacity:1}.modal-dialog{position:relative;width:1000px;max-height:85vh;border-radius:5px;background:var(--white);overflow:hidden;cursor:default}.modal-dialog>*{padding:1rem}.modal-header{background:var(--lightgray)}.modal-header{display:flex;align-items:center}.modal-header .close-modal{cursor:pointer;font-size:1.5rem;background:#b61924;color:#fff;position:absolute;right:25px;-webkit-box-shadow:0 5px 40px -10px rgba(0,0,0,.57);-moz-box-shadow:0 5px 40px -10px rgba(0,0,0,.57)}.modal p+p{margin-top:1rem}[data-animation] .modal-dialog{opacity:0;transition:all .5s var(--bounceEasing)}[data-animation].is-visible .modal-dialog{opacity:1;transition-delay:.2s}[data-animation=slideInOutLeft] .modal-dialog{transform:translateX(-100%)}[data-animation=slideInOutLeft].is-visible .modal-dialog{transform:none}@keyframes mixInAnimations{100%{transform:rotate(0)}}.page-footer{position:absolute;bottom:1rem;right:1rem}.page-footer span{color:#e31b23}#leftDialog{width:50%;float:left}#rightDialog{width:50%;float:right}#actionsText,#allSelectorsText{height:378px;width:100%;resize:none;white-space:pre;margin-bottom:20px}#copyByObjects,#copyElementActions,#download,#generate{cursor:pointer;border:none;background:#b61924;color:#fff;text-transform:uppercase;border-radius:6px;display:inline-block;transition:all .3s ease 0s;-webkit-box-shadow:0 5px 40px -10px rgba(0,0,0,.57);-moz-box-shadow:0 5px 40px -10px rgba(0,0,0,.57)}#download,#generate{font-weight:100;padding:15px;margin-left:20px}#copyByObjects,#copyElementActions{font-size:10;padding:5px;margin-left:25px;margin-bottom:10px}#copyByObjects:hover,#copyElementActions:hover,#download:hover,#generate:hover{font-weight:700;letter-spacing:3px}#download:disabled{background:#696969;cursor:not-allowed;font-weight:100;letter-spacing:0}input[type=text]{font-family:monospace;padding:3;height:30px;width:250px;left:0;outline:0;border:3px solid #b61924;border-color:#b61924;background-color:#fff;font-size:15px;margin-top:5px;margin-left:20px;-webkit-box-shadow:0 5px 40px -10px rgba(0,0,0,.57);-moz-box-shadow:0 5px 40px -10px rgba(0,0,0,.57)}small{position:relative;left:2%;color:#b61924}';
var modelDialogScript = 'const openEls=document.querySelectorAll("[data-open]"),closeEls=document.querySelectorAll("[data-close]"),isVisible="is-visible";for(const e of openEls)e.addEventListener("click",function(){const e=this.dataset.open;document.getElementById(e).classList.add(isVisible)});for(const e of closeEls)e.addEventListener("click",function(){this.parentElement.parentElement.parentElement.classList.remove(isVisible)});document.addEventListener("click",e=>{e.target==document.querySelector(".modal.is-visible")&&document.querySelector(".modal.is-visible").classList.remove(isVisible)}),document.addEventListener("keyup",e=>{"Escape"==e.key&&document.querySelector(".modal.is-visible")&&document.querySelector(".modal.is-visible").classList.remove(isVisible)});';
var getallSelectorButtonEnableScript = 'var allSelectorButton=document.getElementById("viewAllSelectors");1==enableAllSelectorButton?allSelectorButton.disabled=!1:allSelectorButton.disabled=!0;';
var getAllSelectorDownloadScript = 'function updateSelectors(e){""==e&&(e="PageName"),document.getElementById("allSelectorsText").value=allSelectors.join(""),document.getElementById("actionsText").value=allActions.join("").replaceAll("(Page_Name","("+e)}function download(e,t){var n=document.createElement("a");n.setAttribute("href","data:text/plain;charset=utf-8,"+encodeURIComponent(t)),n.setAttribute("download",e),n.style.display="none",document.body.appendChild(n),n.click(),document.body.removeChild(n)}document.getElementById("pageName").addEventListener("keypress",function(e){var t=e.keyCode;65<=t&&t<=90||95<=t&&t<=122||8==t||e.preventDefault(),13==t&&(updateSelectors(document.getElementById("pageName").value),document.getElementById("download").disabled=!1)}),document.getElementById("generate").onclick=function(){updateSelectors(document.getElementById("pageName").value),document.getElementById("download").disabled=!1},document.getElementById("pageName").addEventListener("input",function(e){document.getElementById("download").disabled=!0}),document.getElementById("download").onclick=function(){var e=document.getElementById("pageName").value;""==e&&(e="PageName"),download(e+".java","package uimap;\\n\\nimport org.openqa.selenium.By;\\n\\npublic class "+document.getElementById("pageName").value+" {\\n\\n"+document.getElementById("allSelectorsText").value+"\\n}")};';
var copyToClipboardScript = 'document.getElementById("copyByObjects").onclick=function(){var e=document.getElementById("allSelectorsText");e.removeAttribute("disabled"),e.focus(),e.select();try{var t=document.execCommand("copy");document.getElementById("copyByObjects").innerText="COPY"+(t?" ✅":" ❌"),setTimeout(function(){document.getElementById("copyByObjects").innerText="COPY 📝"},1500)}catch(e){alert("Oops, unable to copy",e)}e.setAttribute("disabled",!0)},document.getElementById("copyElementActions").onclick=function(){var e=document.getElementById("actionsText");e.removeAttribute("disabled"),e.focus(),e.select();try{var t=document.execCommand("copy");document.getElementById("copyElementActions").innerText="COPY"+(t?" ✅":" ❌"),setTimeout(function(){document.getElementById("copyElementActions").innerText="COPY 📝"},1500)}catch(e){alert("Oops, unable to copy",e)}e.setAttribute("disabled",!0)};';

var html = '';
function getSelector(sourceElement) {
  var selectors = {};
  //check if element has an id tag
  if (sourceElement.id) {
    setIDSelector(sourceElement, selectors);
  }
  //if no id, generate xpath expression
  else {
    setXPATHSelector(sourceElement, selectors);
  }
  // generate selection by class
  if (sourceElement.className && sourceElement.className.split(" ").length === 1) {
    setClassNameSelector(sourceElement, selectors);
  }
  //generate selection by element name
  if (sourceElement.name) {
    setNameSelector(sourceElement, selectors);
  }
  // determine the best selector based on selector rankings
  determineBestSelector(selectors);
  return selectors.recommendedSelector;
}

var setIDSelector = function (sourceElement, collector) {
  collector.id = {
    selector: sourceElement.id,
    tag: 'public static final By Element_Name = By.id("' + sourceElement.id + '");',
    element: document.getElementById(sourceElement.id)
  };
  collector.id.selected = collector.id.element === sourceElement;
}

var setNameSelector = function (sourceElement, collector) {
  collector.name = {
    selector: sourceElement.name,
    tag: 'public static final By Element_Name = By.name("' + sourceElement.name + '");',
    element: document.getElementsByName(sourceElement.name)[0]
  };
  collector.name.selected = collector.name.element === sourceElement;
}

var setXPATHSelector = function (sourceElement, collector) {
  var parent;
  var element = sourceElement;
  var xpath = getXpath(element);
  collector.xpath = {};
  collector.xpath.selector = xpath;
  collector.xpath.tag = 'public static final By Element_Name = By.xpath("' + xpath + '");';
  collector.xpath.element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
  collector.xpath.selected = collector.xpath.element === sourceElement;
}

var setClassNameSelector = function (sourceElement, collector) {
  collector.className = {
    selector: sourceElement.className,
    tag: 'public static final By Element_Name = By.className("' + sourceElement.className + '");',
    element: document.getElementsByClassName(sourceElement.className)[0]
  };
  collector.className.selected = collector.className.element === sourceElement
}

var setCssSelector = function (sourceElement, collector) {
  var tagName = sourceElement.tagName;
  var id = sourceElement.id;
  var classNames = sourceElement.className;
  var cssSelector = "";
  if (tagName) {
    if (sourceElement.getAttribute("name")) {
      cssSelector += tagName.toLowerCase() + "[name='" + sourceElement.getAttribute("name") + "']";
    } else {
      cssSelector += tagName.toLowerCase();
    }
  }
  if (id) {
    cssSelector += "#" + id;
  }
  if (classNames) {
    var classes = classNames.split(" ");
    classes.forEach(function (name) {
      cssSelector += "." + name;
    });
  }
  if (cssSelector !== "" && cssSelector !== tagName.toLowerCase()) {
    collector.css = {
      selector: cssSelector,
      tag: 'public static final By Element_Name = By.cssSelector("' + cssSelector + '");',
      element: document.querySelector(cssSelector)
    };
    collector.css.selected = collector.css.element === sourceElement;
  }
}

var determineBestSelector = function (collector) {
  if (collector["id"] && collector["id"].selected) {
    collector.recommendedSelector = collector.id.tag;
  } else if (collector["name"] && collector["name"].selected) {
    collector.recommendedSelector = collector.name.tag;
  } else if (collector["xpath"] && collector["xpath"].selected) {
    collector.recommendedSelector = collector.xpath.tag;
  } else if (collector["className"] && collector["className"].selected) {
    collector.recommendedSelector = collector.className.tag;
  } else if (collector["css"] && collector["css"].selected) {
    collector.recommendedSelector = collector.css.tag;
  }
}

function hasDuplicates(array) {
  return (new Set(array)).size !== array.length;
}

function arraysEqual(a, b) {
  if (a === b) return true;
  if (a == null || b == null) return false;
  if (a.length !== b.length) return false;
  for (var i = 0; i < a.length; ++i) {
    if (a[i] !== b[i]) return false;
  }
  return true;
}

function multiDimensionalUnique(arr) {
  var uniques = [];
  var itemsFound = {};
  for (var i = 0, l = arr.length; i < l; i++) {
    var stringified = JSON.stringify(arr[i]);
    if (itemsFound[stringified]) {
      continue;
    }
    uniques.push(arr[i]);
    itemsFound[stringified] = true;
  }
  return uniques;
}

function getXpath(node) {

  var attrs = node.attributes;
  var i = attrs.length;
  var tagName = node.tagName;
  var map = {};
  var j = 0;
  var val = '';
  var count = 0;

  // no attributes
  if (i == 0) {
    var text = node.innerHTML;
    if ((text.length > 0) && (!text.includes("<")) &&
      (text.indexOf('\'') == -1) && (text.indexOf('"') == -1)) {
      val = "//" + tagName + "[text()='" + text + "']";
      count = getXpathCount(val);
      if (count == 1) {
        return val;
      }
      if (count > 1) {
        val = findXpathWithIndex(val, node);
        return val;
      } else {
        return findXpathWithIndex("//" + node.tagName, node);
      }
    } else {
      return findXpathWithIndex("//" + node.tagName, node);
    }
  } // end if i==0

  var realCount = 0;
  while (j < i) {
    attr = attrs[j];

    if ((attr.name != "style") && (attr.value.indexOf('\'') < 0)) {
      map[attr.name] = attr.value;
      realCount++;
    }
    j++;
  }
  var attrLength = j;
  var Values = Object.values(map);
  var Keys = Object.keys(map);

  // to arrange the keys ie-Attributes based on length of values

  const arrayLength = Object.keys(Values).length;
  var swap;
  var newLen = arrayLength - 1;
  var Values;
  do {
    swap = false;
    for (var i = 0; i < newLen; i++) {
      if (Values[i].length > Values[i + 1].length) {
        var tempA = Values[i];
        var tempB = Keys[i];
        Values[i] = Values[i + 1];
        Keys[i] = Keys[i + 1];
        Values[i + 1] = tempA;
        Keys[i + 1] = tempB;
        swap = true;
      }
    }
    newLen--;
  } while (swap);

  if (realCount == 0) { // undefined case
    var xp = findXpathWithIndex("//" + node.tagName, node);
    return xp;
  } // end of realCount==0

  // Since Id going to be unique , no need to check further attributes
  console.log("check1");
  if (isNotEmpty(map['id'])) {

    val = "//" + tagName + "[@id='" + map['id'] + "']";
    return val;

  }

  // single attribute unique check
  var uniqueXpathList = [];
  for (var i = 0; i < Keys.length; i++) {
    val = "//" + tagName + "[@" + Keys[i] + "='" + map[Keys[i]] + "']";
    count = getXpathCount(val);
    if (count == 1) {
      uniqueXpathList.push(val);
    }
  }

  //text only unique check
  var text = node.innerHTML;
  if ((text.length > 0) && (!text.includes("<")) &&
    (text.indexOf('\'') == -1) && (text.indexOf('"') == -1)) {
    val = "//" + tagName + "[text()='" + text + "']";
    count = getXpathCount(val);
    if (count == 1) {
      uniqueXpathList.push(val);
    }
  }

  //single attribue and text combination check only if innerhtml is text
  if ((text.length > 0) && (!text.includes("<")) &&
    (text.indexOf('\'') == -1) && (text.indexOf('"') == -1)) {
    for (var i = 0; i < Keys.length; i++) {
      val = "//" + tagName + "[@" + Keys[i] + "='" + map[Keys[i]] + "' and text()='" + text + "']";
      count = getXpathCount(val);
      if (count == 1) {
        uniqueXpathList.push(val);
      }
    }
  }

  // all possible attribute combinations check

  for (let xpathAttributeLength = 2; xpathAttributeLength <= Keys.length; xpathAttributeLength++) {
    var counterArray = [];
    var end = [];
    var actualAttributes = Keys;
    var OverallSet = [];

    for (let i = 0; i < xpathAttributeLength; i++) {
      counterArray.push(0);
      end.push(actualAttributes.length - 1);
    }


    for (let j = 0; j < parseInt(end.join("")); j++) {
      counterArray = parseInt(j).toLocaleString('en-US', {
        minimumIntegerDigits: xpathAttributeLength,
        useGrouping: false
      }).split("");
      for (let k = 0; k < xpathAttributeLength; k++) {
        counterArray[k] = parseInt(counterArray[k]);
      }

      var maxFailFlag = false;

      for (let l = 0; l < xpathAttributeLength; l++) {
        if (counterArray[l] >= actualAttributes.length) {
          maxFailFlag = true;
        }
      }
      if (maxFailFlag == false && !hasDuplicates(counterArray)) {
        OverallSet.push(counterArray.sort());

      }

    }
    OverallSet = multiDimensionalUnique(OverallSet);

    for (let m = 0; m < OverallSet.length; m++) {
      var val = "//" + tagName + "[";
      for (let n = 0; n < OverallSet[m].length; n++) {
        val += "@" + actualAttributes[OverallSet[m][n]] + "='" + map[actualAttributes[OverallSet[m][n]]];
        if (n != OverallSet[m].length - 1) {
          val += "' and ";
        }
      }
      val += "']";
      count = getXpathCount(val);
      if (count == 1) {
        uniqueXpathList.push(val);
      }
    }
  }


  // all possible attribute combinations check along with text only if inner html is text
  if ((text.length > 0) && (!text.includes("<")) &&
    (text.indexOf('\'') == -1) && (text.indexOf('"') == -1)) {
    for (let xpathAttributeLength = 2; xpathAttributeLength <= Keys.length; xpathAttributeLength++) {
      var counterArray = [];
      var end = [];
      var actualAttributes = Keys;
      var OverallSet = [];

      for (let i = 0; i < xpathAttributeLength; i++) {
        counterArray.push(0);
        end.push(actualAttributes.length - 1);
      }


      for (let j = 0; j < parseInt(end.join("")); j++) {
        counterArray = parseInt(j).toLocaleString('en-US', {
          minimumIntegerDigits: xpathAttributeLength,
          useGrouping: false
        }).split("");
        for (let k = 0; k < xpathAttributeLength; k++) {
          counterArray[k] = parseInt(counterArray[k]);
        }

        var maxFailFlag = false;

        for (let l = 0; l < xpathAttributeLength; l++) {
          if (counterArray[l] >= actualAttributes.length) {
            maxFailFlag = true;
          }
        }
        if (maxFailFlag == false && !hasDuplicates(counterArray)) {
          OverallSet.push(counterArray.sort());

        }

      }
      OverallSet = multiDimensionalUnique(OverallSet);

      for (let m = 0; m < OverallSet.length; m++) {
        var val = "//" + tagName + "[";
        for (let n = 0; n < OverallSet[m].length; n++) {
          val += "@" + actualAttributes[OverallSet[m][n]] + "='" + map[actualAttributes[OverallSet[m][n]]];
          if (n != OverallSet[m].length - 1) {
            val += "' and ";
          }
        }
        val += "'and text() ='" + text + "']";
        count = getXpathCount(val);
        if (count == 1) {
          uniqueXpathList.push(val);
        }
      }
    }
  }

  console.log(uniqueXpathList);
  //return tag name with index if list of unique xpath is zero
  if (uniqueXpathList.length == 0) {
    var xp = findXpathWithIndex("//" + node.tagName, node);
    return xp;
  }
  //return shortest unique xpath
  else {
    return uniqueXpathList.reduce((a, b) => a.length <= b.length ? a : b)
  }

}

function getXpathCount(val) {

  var nodes = document.evaluate(val, document, null, XPathResult.ANY_TYPE,
    null);
  var results = [],
    nodex;

  while (nodex = nodes.iterateNext()) {
    results.push(nodex);
  }
  return results.length;

}

function findXpathWithIndex(val, node) {

  var nodes = document.evaluate(val, document, null, XPathResult.ANY_TYPE,
    null);
  var results = [],
    nodex;
  var index = 0;
  while (nodex = nodes.iterateNext()) {

    index++;

    if (nodex.isSameNode(node)) {

      return "(" + val + ")[" + index + "]";
    }
  }

}

function getAbsoluteXPath(element) {
  var comp, comps = [];
  var parent = null;
  var xpath = '';
  var getPos = function (element) {
    var position = 1,
      curNode;
    if (element.nodeType == Node.ATTRIBUTE_NODE) {
      return null;
    }
    for (curNode = element.previousSibling; curNode; curNode = curNode.previousSibling) {
      if (curNode.nodeName == element.nodeName) {
        ++position;
      }
    }
    return position;
  };

  if (element instanceof Document) {
    return '/';
  }

  for (; element && !(element instanceof Document); element = element.nodeType == Node.ATTRIBUTE_NODE ? element.ownerElement : element.parentNode) {
    comp = comps[comps.length] = {};
    switch (element.nodeType) {
      case Node.TEXT_NODE:
        comp.name = 'text()';
        break;
      case Node.ATTRIBUTE_NODE:
        comp.name = '@' + element.nodeName;
        break;
      case Node.PROCESSING_INSTRUCTION_NODE:
        comp.name = 'processing-instruction()';
        break;
      case Node.COMMENT_NODE:
        comp.name = 'comment()';
        break;
      case Node.ELEMENT_NODE:
        comp.name = element.nodeName;
        break;
    }
    comp.position = getPos(element);
  }

  for (var i = comps.length - 1; i >= 0; i--) {
    comp = comps[i];
    xpath += '/' + comp.name.toLowerCase();
    if (comp.position !== null) {
      xpath += '[' + comp.position + ']';
    }
  }
  return xpath;
}

function isNotEmpty(val) {
  return (val === undefined || val == null || val.length <= 0) ? false : true;
}

function getAttributesTable(elem) {
  var nodes = [],
    values = [],
    myDATA = [];
  html += '<b>Tag: ' + elem.tagName + '</b>';

  for (var att, i = 0, atts = elem.attributes, n = atts.length; i < n; i++) {
    att = atts[i];
    nodes.push("@" + att.nodeName);
    values.push(att.nodeValue);
  }

  for (var j = 0; j < nodes.length; j++) {
    myDATA.push([nodes[j], values[j]]);
  }

  var currentText = $(elem).clone().children().remove().end().text();
  if (currentText != "") {
    myDATA.push(["text()", currentText]);
  }

  html += '<table class="styled-table">';
  html += '<thead>';
  html += '<tr>';
  html += '<th>S.No</th>';
  html += '<th>Attributes</th>';
  html += '<th>Values</th>';
  html += '</tr>';
  html += '</thead>';
  html += '<tbody>';

  for (var k = 0; k < myDATA.length; k++) {
    html += '<tr>';
    html += '<td>' + (k + 1) + '</td>';
    for (var l = 0; l < myDATA[k].length; l++) {
      html += '<td>' + myDATA[k][l] + '</td>';
    }
    html += '</tr>';
  }
  html += '</tbody>';
  html += '</table>';

  html += '<table class="styled-table">';
  html += '<thead>';
  html += '<tr>';
  html += '<th>Suggested Identifier:</th>';
  html += '</tr>';
  html += '</thead>';
  html += '<tbody>';
  html += '<td>' + getSelector(elem) + '</td>';
  html += '</tbody>';
  html += '</table>';

  html += '<hr>';
}

function isHidden(el) {
  return (el.offsetParent === null)
}

function download(filename, text) {
  var element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
  element.setAttribute('download', filename);

  element.style.display = 'none';
  document.body.appendChild(element);

  element.click();

  document.body.removeChild(element);
}

var getAttribute = function () {
  document.onclick = function (e) {

    chrome.storage.sync.get(['stat'], function (data) {
      console.log(JSON.parse(data.stat));

      var jsonData = JSON.parse(data.stat);
      var config = ["button"];
      var activeFlag = jsonData.Status;
      
      if (activeFlag == "ON") {
        var config = jsonData.Config;
        e.preventDefault();
        e.stopImmediatePropagation();

        var textboxType = ["text", "password", "email", "number", "url", "search", "tel"];
        var buttonInputType = ["submit", "reset", "button", "file", "image"];
        var imageTags = ["img", "map", "area", "picture"];
        var headingTags = ["h1", "h2", "h3", "h4", "h5", "h6"];
        var listTags = ["li", "ul", "ol"];
        var tableTags = ["table", "tr", "td", "th", "tbody", "thead", "tfoot", "col", "colgroup", "caption"];
        var textBoxElems = [];
        var checkBoxElems = [];
        var radioElems = [];
        var dropDownElems = [];
        var buttonElems = [];
        var hyperLinkElems = [];
        var imageElems = [];
        var labelElems = [];
        var divElems = [];
        var spanElems = [];
        var paraElems = [];
        var headingElems = [];
        var listElems = [];
        var tableElems = [];
        var allSelectors = [];
        var allActions = [];
        var FrameSwitchAction = [];
        var allElementCounter = 1;
        var frameCount = window.top.frames.length;

        html = '';


        var all = document.getElementsByTagName("*");

        html += '<html><head><title>🧱 SPOG</title>';
        html += '<style>' + elementsCss + '</style>';
        html += '<style>' + bgAnimationCss + '</style>';
        html += '<style>' + frameWarningCss + '</style>';
        html += '<style>' + modelDialogCss + '</style>';
        html += '</head><body>';
        html += '<div id=particles-js></div>';
        html += '<button class=open-modal data-open=modal1 id=viewAllSelectors type=button>View All Selectors ⏳</button>';

        for (var i = 0, max = all.length; i < max; i++) {
          if (!isHidden(all[i])) {
            if (config.includes("textbox")) {
              if ((all[i].tagName.toLowerCase() == "input" && textboxType.includes(all[i].type)) || all[i].tagName.toLowerCase() == "textarea") {
                textBoxElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("checkbox")) {
              if (all[i].type == "checkbox") {
                checkBoxElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("radiobutton")) {
              if (all[i].type == "radio") {
                radioElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("dropdown")) {
              if (all[i].tagName.toLowerCase() == "select") {
                dropDownElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("button")) {
              if ((all[i].tagName.toLowerCase() == "input" && buttonInputType.includes(all[i].type)) || all[i].tagName.toLowerCase() == "button") {
                buttonElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("images")) {
              if (imageTags.includes(all[i].tagName.toLowerCase())) {
                imageElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("labels")) {
              if (all[i].tagName.toLowerCase() == "label") {
                labelElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("divtags")) {
              if (all[i].tagName.toLowerCase() == "div") {
                divElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("spantags")) {
              if (all[i].tagName.toLowerCase() == "span") {
                spanElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("para")) {
              if (all[i].tagName.toLowerCase() == "p") {
                paraElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("heading")) {
              if (headingTags.includes(all[i].tagName.toLowerCase())) {
                headingElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("lists")) {
              if (listTags.includes(all[i].tagName.toLowerCase())) {
                listElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("table")) {
              if (tableTags.includes(all[i].tagName.toLowerCase())) {
                tableElems.push(all[i]);
                continue;
              }
            }
            if (config.includes("hyperlink")) {
              if (all[i].href != undefined) {
                hyperLinkElems.push(all[i]);
                continue;
              }
            }
          }
        }

        var FrameCheck = window.self;
        for (var k = 0; k >= 0; k++) {
          if (FrameCheck == window.top) {
            FrameSwitchAction.push("driver.switchTo().defaultContent();");
            break;
          }
          else {
            var frameList = FrameCheck.parent.document.getElementsByTagName("iframe");
            for (let i = 0; i < frameList.length; i++) {
              if (frameList[i].contentWindow == FrameCheck) {
                //Check uniue id of frame
                if (frameList[i].id != "" && FrameCheck.parent.document.querySelectorAll('iframe#' + frameList[i].id).length == 1) {
                  FrameSwitchAction.push('driver.switchTo().frame("' + frameList[i].id + '");');
                }
                //Check unique name of frame
                else if (frameList[i].name != "" && FrameCheck.parent.document.querySelectorAll('iframe[name="' + frameList[i].name + '"]').length == 1) {
                  FrameSwitchAction.push('driver.switchTo().frame("' + frameList[i].name + '");');
                }
                //Order of frame respective to parent frame window document
                else {
                  FrameSwitchAction.push('driver.switchTo().frame(' + i + ');');
                }
                //FrameSwitchAction.push('driver.switchTo().frame(' + (frameList[i].id != "" ? '"' + frameList[i].id + '"' : (frameList[i].name != "" ? '"' + frameList[i].name + '"' : i)) + ");");
              }
            }
            FrameCheck = FrameCheck.parent;
          }
        }

        var ActualFrameSwitchCode = FrameSwitchAction.reverse().join("\n");

        if (frameCount > 0) {
          if (window.self != window.top) {
            html += '<div id=frameWarning><span id=closeframeWarning>×</span><strong>Warning!!</strong> Frames Detected, Click inside the Frame to get the attributes of the elements inside it.<br><br><u>Selenium Code - Switch to current frame:</u>' + '<ul><li>' + ActualFrameSwitchCode.replaceAll("\n", "</li><li>") + '</li></ul>' + '</div>';
            allActions.push("//To switch to the Current Frame\n\n" + ActualFrameSwitchCode + "\n\n");
          }
          else {
            html += '<div id=frameWarning><span id=closeframeWarning>×</span><strong>Warning!!</strong> Frames Detected, Click inside the Frame to get the attributes of the elements inside it.</div>';
          }

        }

        if (config.includes("textbox")) {
          if (textBoxElems.length > 0) {
            html += '<h1>Text Boxes</h1>';
            allSelectors.push("//TextBoxes\n\n");
            allActions.push("//TextBoxes\n\n");
            for (var i = 0, max = textBoxElems.length; i < max; i++) {
              getAttributesTable(textBoxElems[i]);
              allSelectors.push(getSelector(textBoxElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").sendKeys(\"text\");" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Text Boxes Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("checkbox")) {
          if (checkBoxElems.length > 0) {
            html += '<h1>Check Boxes</h1>';
            allSelectors.push("//CheckBoxes\n\n");
            allActions.push("//CheckBoxes\n\n");
            for (var i = 0, max = checkBoxElems.length; i < max; i++) {
              getAttributesTable(checkBoxElems[i]);
              allSelectors.push(getSelector(checkBoxElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Check Boxes Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("radiobutton")) {
          if (radioElems.length > 0) {
            html += '<h1>Radio Buttons</h1>';
            allSelectors.push("//RadioButtons\n\n");
            allActions.push("//RadioButtons\n\n");
            for (var i = 0, max = radioElems.length; i < max; i++) {
              getAttributesTable(radioElems[i]);
              allSelectors.push(getSelector(radioElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Radio Buttons Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("dropdown")) {
          if (dropDownElems.length > 0) {
            html += '<h1>Dropdowns</h1>';
            allSelectors.push("//DropDowns\n\n");
            allActions.push("//DropDowns\n\n");
            for (var i = 0, max = dropDownElems.length; i < max; i++) {
              getAttributesTable(dropDownElems[i]);
              allSelectors.push(getSelector(dropDownElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("Select dropdown = new Select(driver.findElement(Page_Name.Element" + allElementCounter + "));" + "\n");
              allActions.push("dropdown.selectByValue(\"text\");" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Dropdowns Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("button")) {
          if (buttonElems.length > 0) {
            html += '<h1>Buttons</h1>';
            allSelectors.push("//Buttons\n\n");
            allActions.push("//Buttons\n\n");
            for (var i = 0, max = buttonElems.length; i < max; i++) {
              getAttributesTable(buttonElems[i]);
              allSelectors.push(getSelector(buttonElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Buttons Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("images")) {
          if (imageElems.length > 0) {
            html += '<h1>Images</h1>';
            allSelectors.push("//images\n\n");
            allActions.push("//images\n\n");
            for (var i = 0, max = imageElems.length; i < max; i++) {
              getAttributesTable(imageElems[i]);
              allSelectors.push(getSelector(imageElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Images Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("labels")) {
          if (labelElems.length > 0) {
            html += '<h1>Labels</h1>';
            allSelectors.push("//labels\n\n");
            allActions.push("//labels\n\n");
            for (var i = 0, max = labelElems.length; i < max; i++) {
              getAttributesTable(labelElems[i]);
              allSelectors.push(getSelector(labelElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Labels Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("divtags")) {
          if (divElems.length > 0) {
            html += '<h1>Div</h1>';
            allSelectors.push("//divtags\n\n");
            allActions.push("//divtags\n\n");
            for (var i = 0, max = divElems.length; i < max; i++) {
              getAttributesTable(divElems[i]);
              allSelectors.push(getSelector(divElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Div Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("spantags")) {
          if (spanElems.length > 0) {
            html += '<h1>Span</h1>';
            allSelectors.push("//spantags\n\n");
            allActions.push("//spantags\n\n");
            for (var i = 0, max = spanElems.length; i < max; i++) {
              getAttributesTable(spanElems[i]);
              allSelectors.push(getSelector(spanElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Span Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("para")) {
          if (paraElems.length > 0) {
            html += '<h1>Paragraph</h1>';
            allSelectors.push("//para\n\n");
            allActions.push("//para\n\n");
            for (var i = 0, max = paraElems.length; i < max; i++) {
              getAttributesTable(paraElems[i]);
              allSelectors.push(getSelector(paraElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Paragraph Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("heading")) {
          if (headingElems.length > 0) {
            html += '<h1>Heading</h1>';
            allSelectors.push("//heading\n\n");
            allActions.push("//heading\n\n");
            for (var i = 0, max = headingElems.length; i < max; i++) {
              getAttributesTable(headingElems[i]);
              allSelectors.push(getSelector(headingElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Heading Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("lists")) {
          if (listElems.length > 0) {
            html += '<h1>Lists</h1>';
            allSelectors.push("//lists\n\n");
            allActions.push("//lists\n\n");
            for (var i = 0, max = listElems.length; i < max; i++) {
              getAttributesTable(listElems[i]);
              allSelectors.push(getSelector(listElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No List Found</h1>';
            html += '<hr>';
          }
        }

        if (config.includes("table")) {
          if (tableElems.length > 0) {
            html += '<h1>Table</h1>';
            allSelectors.push("//table\n\n");
            allActions.push("//table\n\n");
            for (var i = 0, max = tableElems.length; i < max; i++) {
              getAttributesTable(tableElems[i]);
              allSelectors.push(getSelector(tableElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Table Found</h1>';
            html += '<hr>';
          }
        }
        if (config.includes("hyperlink")) {
          if (hyperLinkElems.length > 0) {
            html += '<h1>Hyperlinks</h1>';
            allSelectors.push("//HyperLinks\n\n");
            allActions.push("//HyperLinks\n\n");
            for (var i = 0, max = hyperLinkElems.length; i < max; i++) {
              getAttributesTable(hyperLinkElems[i]);
              allSelectors.push(getSelector(hyperLinkElems[i]).replace(new RegExp('^((\\S+ ){4})(\\S+)'), "$1Element" + allElementCounter) + "\n");
              allActions.push("driver.findElement(Page_Name.Element" + allElementCounter + ").Click();" + "\n");
              allElementCounter++;
            }
            allSelectors.push("\n");
            allActions.push("\n");
          } else {
            html += '<h1>No Hyperlinks Found</h1>';
            html += '<hr>';
          }
        }

        if (frameCount > 0) {
          if (window.self != window.top) {
            allActions.push("//To switch to the Default Parent Frame\n\ndriver.switchTo().defaultContent();\n\n");
          }
        }

        html += '<div id=modal1 class=modal data-animation=slideInOutLeft><div class=modal-dialog> <header class=modal-header><input type=text id=pageName placeholder="Enter the Page Name Here!"> <button id=generate type=button>Generate ⚙️</button><button id=download type=button disabled>Download UImap 💾</button><button aria-label="close modal" class=close-modal data-close>✕</button></header> <section class=modal-content><div id=leftDialog><small>By Objects</small><button id="copyByObjects">COPY 📝</button><textarea disabled id=allSelectorsText></textarea></div><div id=rightDialog><small>Element Actions</small><button id="copyElementActions">COPY 📝</button><textarea disabled id=actionsText></textarea></div> </section></div></div>';

        html += '<script src="chrome-extension://'+chrome.runtime.id+'/ThirdParty/jquery-min.js"></script>'; // remove this dummy line - Script injection below wont work since violation of policy - chrome dev bug :)

        if (frameCount > 0) {
          html += '<script>' + frameWarningScript + '</script>';
        }
        html += '<script>' + bgAnimationScript + '</script>';
        html += '<script> var enableAllSelectorButton =' + JSON.stringify(allSelectors.length > 0 ? true : false)
          + ';' + getallSelectorButtonEnableScript + '</script>';
        html += '<script>' + modelDialogScript + '</script>';
        html += '<script> var allSelectors=' + JSON.stringify(allSelectors) + ";" + 'var allActions=' + JSON.stringify(allActions) + ";" + getAllSelectorDownloadScript + '</script>';
        html += '<script>' + copyToClipboardScript + '</script>';

        html += '</body></html>';
        var x = window.open('');
        x.document.write(html);

        chrome.storage.sync.set({
          stat: '{"Status":"OFF","Config":[]}'
        }, function () { });
        
      }
    });
  }
}

getAttribute()
