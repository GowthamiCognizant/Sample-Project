var config = [];

$("#textbox").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("textbox")) {
      config.push("textbox");
    }
  } else {
    if (config.includes("textbox")) {
      config = config.filter(e => e !== "textbox");
    }
  }
});


$("#checkbox").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("checkbox")) {
      config.push("checkbox");
    }
  } else {
    if (config.includes("checkbox")) {
      config = config.filter(e => e !== "checkbox");
    }
  }
});


$("#radiobutton").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("radiobutton")) {
      config.push("radiobutton");
    }
  } else {
    if (config.includes("radiobutton")) {
      config = config.filter(e => e !== "radiobutton");
    }
  }
});


$("#dropdown").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("dropdown")) {
      config.push("dropdown");
    }
  } else {
    if (config.includes("dropdown")) {
      config = config.filter(e => e !== "dropdown");
    }
  }
});


$("#button").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("button")) {
      config.push("button");
    }
  } else {
    if (config.includes("button")) {
      config = config.filter(e => e !== "button");
    }
  }
});


$("#hyperlink").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("hyperlink")) {
      config.push("hyperlink");
    }
  } else {
    if (config.includes("hyperlink")) {
      config = config.filter(e => e !== "hyperlink");
    }
  }
});

$("#img").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("images")) {
      config.push("images");
    }
  } else {
    if (config.includes("images")) {
      config = config.filter(e => e !== "images");
    }
  }
});

$("#label").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("labels")) {
      config.push("labels");
    }
  } else {
    if (config.includes("labels")) {
      config = config.filter(e => e !== "labels");
    }
  }
});

$("#divtags").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("divtags")) {
      config.push("divtags");
    }
  } else {
    if (config.includes("divtags")) {
      config = config.filter(e => e !== "divtags");
    }
  }
});

$("#spantags").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("spantags")) {
      config.push("spantags");
    }
  } else {
    if (config.includes("spantags")) {
      config = config.filter(e => e !== "spantags");
    }
  }
});

$("#para").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("para")) {
      config.push("para");
    }
  } else {
    if (config.includes("para")) {
      config = config.filter(e => e !== "para");
    }
  }
});

$("#heading").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("heading")) {
      config.push("heading");
    }
  } else {
    if (config.includes("heading")) {
      config = config.filter(e => e !== "heading");
    }
  }
});

$("#lists").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("lists")) {
      config.push("lists");
    }
  } else {
    if (config.includes("lists")) {
      config = config.filter(e => e !== "lists");
    }
  }
});

$("#table").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("table")) {
      config.push("table");
    }
  } else {
    if (config.includes("table")) {
      config = config.filter(e => e !== "table");
    }
  }
});

async function getCurrentTab() {
  let queryOptions = { active: true, lastFocusedWindow: true };
  // `tab` will either be a `tabs.Tab` instance or `undefined`.
  let [tab] = await chrome.tabs.query(queryOptions);
  return tab.id;
}

$("#apply").click(function (tab) {
  console.log(tab);

  if (config.length != 0) {
    chrome.storage.sync.set({
      stat: '{"Status":"ON","Config":'+JSON.stringify(config)+'}'
    }, function () { });

    var tempExists = document.getElementById("tempText");
    if (tempExists != null) {
      document.getElementById("tempText").remove();
    }
    var node = document.createElement("B");
    node.setAttribute("id", "tempText");
    var textnode = document.createTextNode("Note: Click inside the frame to view the attributes of elements");
    node.appendChild(textnode);
    document.getElementById("tempHolder").appendChild(node);

    getCurrentTab().then(function(tabIdentifier){
      chrome.scripting.executeScript({
        target: {tabId: tabIdentifier, allFrames: true},
        files: ['ThirdParty/jquery-min.js'],
    },function(){
      chrome.scripting.executeScript({
        target: {tabId: tabIdentifier, allFrames: true},
        files: ['inject.js'],
    })
    });
    })
      
  }
  else {
    chrome.storage.sync.set({
      stat: '{"Status":"OFF","Config":[]}'
    }, function () { });

    var tempExists = document.getElementById("tempText");
    if (tempExists != null) {
      document.getElementById("tempText").remove();
    }
    var node = document.createElement("B");
    node.setAttribute("id", "tempText");
    var textnode = document.createTextNode("Note: Select atleast one type of element");
    node.appendChild(textnode);
    document.getElementById("tempHolder").appendChild(node);
  }
});


$("#disable").click(function (tab) {
  chrome.storage.sync.set({
    stat: '{"Status":"OFF","Config":[]}'
  }, function () { });

  var tempExists = document.getElementById("tempText");
  if (tempExists != null) {
    document.getElementById("tempText").remove();
  }
});
