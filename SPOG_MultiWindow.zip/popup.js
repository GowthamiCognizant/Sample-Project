var config = [];

$("#textbox").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("textbox")) {
      config.push("textbox");
    }
  } else {
    if (config.includes("textbox")) {
      config = config.filter(e => e !== "textbox");
    }
  }
});


$("#checkbox").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("checkbox")) {
      config.push("checkbox");
    }
  } else {
    if (config.includes("checkbox")) {
      config = config.filter(e => e !== "checkbox");
    }
  }
});


$("#radiobutton").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("radiobutton")) {
      config.push("radiobutton");
    }
  } else {
    if (config.includes("radiobutton")) {
      config = config.filter(e => e !== "radiobutton");
    }
  }
});


$("#dropdown").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("dropdown")) {
      config.push("dropdown");
    }
  } else {
    if (config.includes("dropdown")) {
      config = config.filter(e => e !== "dropdown");
    }
  }
});


$("#button").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("button")) {
      config.push("button");
    }
  } else {
    if (config.includes("button")) {
      config = config.filter(e => e !== "button");
    }
  }
});


$("#hyperlink").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("hyperlink")) {
      config.push("hyperlink");
    }
  } else {
    if (config.includes("hyperlink")) {
      config = config.filter(e => e !== "hyperlink");
    }
  }
});

$("#img").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("images")) {
      config.push("images");
    }
  } else {
    if (config.includes("images")) {
      config = config.filter(e => e !== "images");
    }
  }
});

$("#label").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("labels")) {
      config.push("labels");
    }
  } else {
    if (config.includes("labels")) {
      config = config.filter(e => e !== "labels");
    }
  }
});

$("#divtags").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("divtags")) {
      config.push("divtags");
    }
  } else {
    if (config.includes("divtags")) {
      config = config.filter(e => e !== "divtags");
    }
  }
});

$("#spantags").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("spantags")) {
      config.push("spantags");
    }
  } else {
    if (config.includes("spantags")) {
      config = config.filter(e => e !== "spantags");
    }
  }
});

$("#para").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("para")) {
      config.push("para");
    }
  } else {
    if (config.includes("para")) {
      config = config.filter(e => e !== "para");
    }
  }
});

$("#heading").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("heading")) {
      config.push("heading");
    }
  } else {
    if (config.includes("heading")) {
      config = config.filter(e => e !== "heading");
    }
  }
});

$("#lists").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("lists")) {
      config.push("lists");
    }
  } else {
    if (config.includes("lists")) {
      config = config.filter(e => e !== "lists");
    }
  }
});

$("#table").on('change', function () {

  if ($(this).is(':checked')) {
    if (!config.includes("table")) {
      config.push("table");
    }
  } else {
    if (config.includes("table")) {
      config = config.filter(e => e !== "table");
    }
  }
});


function updateTempTextAndStat(color, text) {
  var tempExists = document.getElementById("tempText");
  if (tempExists != null) {
    document.getElementById("tempText").remove();
  }
  var node = document.createElement("B");
  node.setAttribute("id", "tempText");
  var textnode = document.createTextNode(text);
  node.style.color = color;
  node.appendChild(textnode);
  document.getElementById("tempHolder").appendChild(node);
}


async function getAllTabs() {
  let windows = await chrome.windows.getAll({ populate: true });
  let allTabs = windows.flatMap(window => window.tabs);
  return allTabs;
}


getAllTabs().then(function (tabs) {
  tabs.forEach(tab => {
    if (!tab.url.startsWith("chrome://")) {
      var option = document.createElement('option');
      option.value = tab.id;
      option.textContent = tab.title || 'Untitled';
      tabSelect.appendChild(option);
    }
  });
});


$("#apply").click(function () {
  var selectedTabId = parseInt(tabSelect.value, 10);
  if (config.length == 0) {
    chrome.storage.sync.set({
      stat: '{"Status":"OFF","Config":[]}'
    }, function () { });
    updateTempTextAndStat("red", "Note: Select at least one type of element")
  }
  else if (isNaN(selectedTabId)) {
    chrome.storage.sync.set({
      stat: '{"Status":"OFF","Config":[]}'
    }, function () { });
    updateTempTextAndStat("red", "Note: Select a Valid Tab")
  }
  else {
    getAllTabs().then(function (tabs) {
      var InjectedCount = 0;
      // Execute scripts on each tab
      tabs.forEach(tab => {
        if (!tab.url.startsWith("chrome://")) {
          if (selectedTabId == tab.id) {
            chrome.scripting.executeScript({
              target: { tabId: tab.id, allFrames: true },
              files: ['ThirdParty/jquery-min.js'],
            }, function () {
              chrome.scripting.executeScript({
                target: { tabId: tab.id, allFrames: true },
                files: ['inject.js'],
              });
            });
            InjectedCount++;
          }
          else {
            chrome.scripting.executeScript({
              target: { tabId: tab.id, allFrames: true },
              files: ['clearInject.js'],
            });
          }
        }
      });

      if (InjectedCount == 1) {
        chrome.storage.sync.set({
          stat: '{"Status":"ON","Config":' + JSON.stringify(config) + '}'
        }, function () { });
        updateTempTextAndStat("green", "Note: Click inside the frame to view the attributes of elements");
      }
      else if (InjectedCount == 0) {
        chrome.storage.sync.set({
          stat: '{"Status":"OFF","Config":' + JSON.stringify(config) + '}'
        }, function () { });
        updateTempTextAndStat("red", "Note: Window Already Closed");
      }
      else {
        updateTempTextAndStat("orange", "Note: Injected Script To Multiple Pages/Times, Proceed With Caution!");
      }

    });
  }
});


$("#disable").click(function (tab) {
  chrome.storage.sync.set({
    stat: '{"Status":"OFF","Config":[]}'
  }, function () { });

  var tempExists = document.getElementById("tempText");
  if (tempExists != null) {
    document.getElementById("tempText").remove();
  }
  getAllTabs().then(function (tabs) {
    tabs.forEach(tab => {
      if (!tab.url.startsWith("chrome://")) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id, allFrames: true },
          files: ['clearInject.js'],
        });
      }
    });
  });
});
