if (window.runInject) {
    delete window.runInject;
    //console.log("Injected function has been removed.");
  }
